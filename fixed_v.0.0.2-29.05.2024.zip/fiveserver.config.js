// fiveserver.config.js
module.exports = {
  injectBody: true, // enable instant update
  navigate: true, // enable auto-navigation
};