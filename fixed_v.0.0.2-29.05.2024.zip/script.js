function bene() {
    window.location.href = '/';
}
function links() {
    window.location.href = '/links/';
}

function projects() {
    window.location.href = '/projects/';
}

function login() {
    window.location.href = 'https://dashboard.nxBene.de';
}